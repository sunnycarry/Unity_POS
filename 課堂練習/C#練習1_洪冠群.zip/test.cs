﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test : MonoBehaviour {

    Robot r;
	// Use this for initialization
	void Start () {
        r = new Robot();
	}
	
	// Update is called once per frame
	void Update () {

        setLan();
        displayName();
        displayInfo();
        robotWalk();
        robotSpeak();

    }

    void displayName()
    {
        if(Input.GetKeyDown(KeyCode.R))
        {
            Debug.Log("My name is : " + r.name);
        }
    }

    void displayInfo()
    {
        if (Input.GetKeyDown(KeyCode.T))
        {
            Debug.Log("身高"+r.height);
            Debug.Log("體重"+r.weight);
        }
    }

    
    void setLan()
    {
        if (Input.GetKeyDown(KeyCode.Q))
        {
            r.setLanguange("English");
            Debug.Log("Set language : English");
        }
        else if (Input.GetKeyDown(KeyCode.W))
        {
            r.setLanguange("Chinese");
            Debug.Log("Set language : Chinese");
        }
        else if (Input.GetKeyDown(KeyCode.E))
        {
            r.setLanguange("Others");
            Debug.Log("Set language : Others");
        }
    }

    void robotWalk()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            r.walk(10);
        }
    }

    void robotSpeak()
    {
        if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            r.speak();
        }
    }


}
