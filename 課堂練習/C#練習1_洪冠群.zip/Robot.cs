﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Robot{

    public string  name,language;
    public float height, weight;

	// Use this for initialization
	void Start () {
       /* this.language = "no";
        this.height = 160.0f;
        this.weight = 100.0f;
        */
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public Robot()
    {
        name = "Mr.Robot";
        language = "no";
        height = 160.0f;
        weight = 160.0f;
    }

    public Robot(string s)
    {
        name = s;
    }

    public Robot(string s, string language)
    {
        name = s;
        this.language = language;
    }

    public void setLanguange(string s)
    {
        this.language = s;
    }

    public void walk(int step)
    {
        Debug.Log("準備前進" + step + "步");
        int real_step = step;
        if (step < 0)
        {
            Debug.Log("步數不能是負值");
            return;
        }

        else if (weight > 100)
        {
            Debug.Log("太胖了");
            real_step = (step > 5) ? 5 : step;
        }
            
        
        for(int i = 1;i<=real_step;++i)
            Debug.Log("正在走第" + i + "步");
        Debug.Log("走完了");
    }

    public void speak()
    {

        if (this.language == "no")
            Debug.Log("need to be assigned");
        else if (this.language == "English")
            Debug.Log("Hello");
        else if (this.language == "Chinese")
            Debug.Log("你好");
        else
            Debug.Log("Y&@hF&$@(*Y@(*GF$");

    }

   
}
