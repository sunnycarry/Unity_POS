﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Work : MonoBehaviour {



	// Use this for initialization
	void Start () {
        Engineer e = new Engineer(4);
        Art a = new Art(5);
        Planner p = new Planner(6);
        
        Debug.Log("上班時間：");
        e.showid();
        e.work();
        a.work();
        p.work();

        Debug.Log("休息時間：");
        e.qk();


        Debug.Log("下班時間：");
        e.offwork();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public abstract class Employee
    {

        public int id;

        public Employee(int num)
        {
            this.id = num;
        }

        public abstract void work();


        public void qk()
        {
            Debug.Log("休息囉");
        }

        public void offwork()
        {
            Debug.Log("下班囉");
        }

        public void showid()
        {
            Debug.Log("My id is " + this.id);
        }
    }

    class Engineer : Employee
    {
        public Engineer(int num) : base(num)
        {
        }

        public override void work()
        {
            Debug.Log("........Engineer is working........");
            Debug.Log("coding");
            Debug.Log("complete!");
            Debug.Log("debug...");
        }

    }


    class Planner : Employee
    {
        public Planner(int num) : base(num)
        {
        }

        public override void work()
        {
            Debug.Log("........Planner is working........");
            Debug.Log("thinking");
            Debug.Log("trying");
            Debug.Log("planing");
        }
    }


    class Art : Employee
    {
        public Art(int num) : base(num)
        {
        }

        public override void work()
        {
            Debug.Log(".......Art is working........");
            Debug.Log("Painting");
            Debug.Log("and painting");
            Debug.Log("still painting");
        }
    }
}
